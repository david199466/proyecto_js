//PROGRAMACION DE TRANSICION DE AMBOS FORMULARIOS
const signUpButton=document.getElementById("signUp");//boton de registro
const signInButton=document.getElementById("signUp");//boton ingreso
const container=document.getElementById("container");
const boost=document.getElementById("boost");
// programar evento click mostrar form registro
signUpButton.addEventListener("click",() =>{
    container.classList.add("right-panel-active");
    boost.style.visibility="hidden";
});
// programar evento click ocultar form registro
signInbutton.addEventListener("click",() =>{
    container.classList.remove("right-panel-active");
    boost.style.visibility="visible";
});
// mostrar contraseña
function mostrarseña()
{
    var tipo= document.getElementById("seña");
    if(tipo.type=="password")
    {
        tipo.type="text";
    }else{
        tipo.type="password";
    }
}